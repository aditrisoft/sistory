/*** 05 Nopember 2016****/
/*** Created by Adi *****/
    var textarea = document.getElementById('txtpesan');
    textarea.addEventListener('keydown', autosize);  
    var textarea1 = document.getElementById('txtpesan1');
    textarea1.addEventListener('keydown', autosize);                 
    var textarea2 = document.getElementById('txtpesan2');
    textarea2.addEventListener('keydown', autosize);                 
    var textarea3 = document.getElementById('txtpesan3');
    textarea3.addEventListener('keydown', autosize);                 
    var textarea4 = document.getElementById('txtpesan4');
    textarea4.addEventListener('keydown', autosize);                 
    var textarea5 = document.getElementById('txtpesan5');
    textarea5.addEventListener('keydown', autosize);                 
    var textarea6 = document.getElementById('txtpesan6');
    textarea6.addEventListener('keydown', autosize);                 


 

    function autosize(){
        /*
      var el = this;
      setTimeout(function(){
        el.style.cssText = 'height:20px; padding:10px';
        el.style.cssText = 'height:' + el.scrollHeight + 'px';
      },0);
      */
    } 

